/* 인테리어 시공 견적·시공관리 — 공통 인터랙션
   프로토타입용 최소 동작: 탭 / 아코디언 / 칩 / 토스트 / 모달 / 단계 진행 /
   비포·애프터 손잡이 / 공정표 막대 펼침 / 사진 일지 접기 / 잠금 해제 / 서명 */
(function () {
  'use strict';

  function on(sel, ev, fn) {
    document.addEventListener(ev, function (e) {
      var t = e.target.closest(sel);
      if (t) fn(e, t);
    });
  }

  /* 탭 — 같은 묶음 안에서만 활성 전환. data-go 가 있으면 해당 화면으로 이동.
     ⚠ 탭과 몸통은 «같은 상자» 안에 있어야 한다 — box.parentElement 안에서만 찾는다. */
  on('.tab', 'click', function (e, t) {
    if (t.dataset.go) { location.href = t.dataset.go; return; }
    var box = t.closest('.tabs, .tabs-pill');
    if (!box) return;
    box.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('on'); });
    t.classList.add('on');
    var key = t.dataset.pane;
    if (key) {
      var scope = box.parentElement;
      scope.querySelectorAll('[data-pane-body]').forEach(function (p) {
        p.hidden = p.dataset.paneBody !== key;
      });
    }
  });

  /* 잠기는 버튼은 <a> 로 못 만든다 — <button data-go="…"> 로 만들고 여기서 옮긴다. */
  on('.btn[data-go]', 'click', function (e, t) {
    if (t.disabled || t.classList.contains('is-off')) return;
    location.href = t.dataset.go;
  });

  /* 아코디언 */
  on('.acc-q', 'click', function (e, t) {
    t.closest('.acc-item').classList.toggle('on');
  });

  /* 칩 필터 */
  on('.chip', 'click', function (e, t) {
    if (t.dataset.go) { location.href = t.dataset.go; return; }
    if (t.classList.contains('is-off')) return;
    t.classList.toggle('on');
  });

  /* 찜하기 */
  on('.heart', 'click', function (e, t) {
    e.preventDefault();
    var isOn = t.classList.toggle('on');
    t.textContent = isOn ? '♥' : '♡';
    toast(isOn ? '찜한 사례에 담았어요' : '찜을 해제했어요');
  });

  /* 토글 스위치 */
  on('.toggle', 'click', function (e, t) {
    t.classList.toggle('on');
    if (t.dataset.toast) toast(t.dataset.toast);
  });

  /* 고르는 카드(라디오) */
  on('.radio', 'click', function (e, t) {
    if (t.classList.contains('is-off')) return;
    var name = t.dataset.group;
    if (!name) return;
    document.querySelectorAll('.radio[data-group="' + name + '"]').forEach(function (x) { x.classList.remove('on'); });
    t.classList.add('on');
  });

  /* 별점 입력 */
  on('.rate-in .st b', 'click', function (e, t) {
    var box = t.closest('.st');
    var list = Array.prototype.slice.call(box.querySelectorAll('b'));
    var i = list.indexOf(t);
    list.forEach(function (x, n) {
      x.classList.toggle('on', n <= i);
      x.textContent = n <= i ? '★' : '☆';
    });
    var v = box.parentElement.querySelector('.v');
    if (v) v.textContent = (i + 1) + '점';
  });

  /* 동의 체크박스로 버튼 잠금 해제 — data-unlock="버튼id" */
  document.addEventListener('change', function (e) {
    var t = e.target.closest('[data-unlock]');
    if (!t) return;
    var b = document.getElementById(t.dataset.unlock);
    if (!b) return;
    b.disabled = !t.checked;
    b.classList.toggle('is-off', !t.checked);
  });

  /* 여러 체크가 «모두» 체크돼야 여는 버튼 — data-unlock-all="버튼id", 같은 [data-agree-scope] 안 [data-agree] 전부 */
  function syncUnlockAll(scope) {
    scope.querySelectorAll('[data-unlock-all]').forEach(function (any) {
      var b = document.getElementById(any.dataset.unlockAll);
      if (!b) return;
      var boxes = scope.querySelectorAll('[data-agree]');
      var all = boxes.length > 0 && Array.prototype.every.call(boxes, function (x) { return x.checked; });
      b.disabled = !all;
      b.classList.toggle('is-off', !all);
    });
  }
  document.addEventListener('change', function (e) {
    var t = e.target.closest('[data-agree]');
    if (!t) return;
    var scope = t.closest('[data-agree-scope]') || document;
    syncUnlockAll(scope);
  });
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-agree-scope]').forEach(syncUnlockAll);
  });

  /* 전체 동의 — 아래 항목을 모두 따라가게 */
  document.addEventListener('change', function (e) {
    var t = e.target.closest('[data-agree-all]');
    if (!t) return;
    var scope = t.closest('[data-agree-scope]') || document;
    scope.querySelectorAll('[data-agree]').forEach(function (x) { x.checked = t.checked; });
    syncUnlockAll(scope);
  });

  /* 닫기 */
  on('[data-close]', 'click', function (e, t) {
    var box = t.closest(t.dataset.close || '*');
    if (box) box.remove();
  });

  /* 모달 열기 */
  on('[data-modal]', 'click', function (e, t) {
    var tpl = document.getElementById(t.dataset.modal);
    if (!tpl) return;
    var d = document.createElement('div');
    d.className = 'dim';
    d.innerHTML = tpl.innerHTML;
    d.addEventListener('click', function (ev) {
      if (ev.target === d || ev.target.closest('[data-dismiss]')) d.remove();
    });
    document.body.appendChild(d);
    initCompare(d);
  });

  /* ---------- ★ 비포·애프터 손잡이 ----------
     input[type=range] 를 겹쳐 두고, 값에 맞춰 --cp(after 이미지가 드러나는 지점)를 옮긴다. */
  function initCompare(scope) {
    (scope || document).querySelectorAll('.compare').forEach(function (box) {
      if (box.dataset.bound) return;
      box.dataset.bound = '1';
      var range = box.querySelector('.cp-range');
      if (!range) return;
      var set = function (v) {
        box.style.setProperty('--cp', v + '%');
      };
      range.addEventListener('input', function () { set(range.value); });
    });
  }
  document.addEventListener('DOMContentLoaded', function () { initCompare(document); });

  /* ---------- ★ 공정표(간트) 막대 — 누르면 상세가 펼쳐진다 ---------- */
  on('.gantt-bar', 'click', function (e, t) {
    var key = t.dataset.detail;
    if (!key) return;
    document.querySelectorAll('.gantt-detail').forEach(function (d) {
      d.hidden = d.dataset.detail !== key || !d.hidden;
    });
  });

  /* ---------- ★ 현장 사진 일지 — 날짜 묶음 접기·펴기 ---------- */
  on('.plog-hd', 'click', function (e, t) {
    var day = t.closest('.plog-day');
    if (day) day.classList.toggle('closed');
  });

  /* ---------- 돈 표시 — 두 화면 이상에서 같이 쓴다 ---------- */
  function 돈(n) { return Math.round(n).toLocaleString('ko-KR') + '원'; }
  function 만원(n) { return Math.round(n / 10000).toLocaleString('ko-KR') + '만원'; }

  /* ---------- ★ OW-01 현장 대시보드 — 기간 select를 바꾸면 매출·미수금이 다시 계산된다.
     「진행 중 현장」·「밀린 공정」은 지금 순간의 현장 목록을 그대로 센 값이라 기간과
     무관해 그대로 둔다. ---------- */
  document.addEventListener('change', function (e) {
    var sel = e.target.closest('[data-period-pick]');
    if (!sel) return;
    var opt = sel.selectedOptions[0];
    var 매출El = document.querySelector('[data-stat-num="매출"]');
    var 미수금El = document.querySelector('[data-stat-num="미수금"]');
    var 라벨El = document.querySelector('[data-stat-label="매출"]');
    if (매출El) 매출El.textContent = Math.round(Number(opt.dataset.매출) / 10000).toLocaleString('ko-KR');
    if (미수금El) 미수금El.textContent = Math.round(Number(opt.dataset.미수금) / 10000).toLocaleString('ko-KR');
    if (라벨El) 라벨El.textContent = opt.dataset.매출라벨;
  });

  /* ---------- ★ CS-04 자재·마감 둘러보기 — 카드를 고르면 위 미리보기 사진이 바뀌고,
     「담기」를 누르면 오른쪽 「내가 고른 자재」에 쌓여 추가금이 다시 계산된다.
     한 부위(바닥·벽·주방·욕실·창호)당 하나만 담긴다 — 새로 담으면 그 부위의 예전 것을 대신한다.
     이 화면엔 평수를 따로 묻지 않아 32평(다른 화면의 ESTIMATE_BASE.pyeong과 같음)을 그대로 쓴다. */
  var cs04담은것 = { 바닥: { nm: '강마루', add: 0 }, 주방: { nm: '엔지니어드스톤', add: 65000 } };
  function cs04합계갱신() {
    var listEl = document.querySelector('[data-cart-list]');
    var totalEl = document.querySelector('[data-cart-total]');
    if (!listEl || !totalEl) return;
    var parts = Object.keys(cs04담은것);
    listEl.innerHTML = parts.length
      ? parts.map(function (p) {
        var it = cs04담은것[p];
        var v = it.add === 0 ? '+0원' : it.add < 0 ? 돈(it.add) + '/평' : '+' + 돈(it.add) + '/평';
        return '<div class="row-b"><span class="t-sub">' + p + ' — ' + it.nm + '</span><span class="t-sub' + (it.add > 0 ? ' acc' : '') + '">' + v + '</span></div>';
      }).join('')
      : '<p class="t-sub">아직 담은 자재가 없어요</p>';
    var sum = parts.reduce(function (s, p) { return s + cs04담은것[p].add * 32; }, 0);
    totalEl.textContent = (sum >= 0 ? '+' : '') + 만원(sum);
  }
  on('[data-part]', 'click', function (e, t) {
    var img = t.querySelector('.ph img[data-예시]');
    var previewImg = document.querySelector('[data-preview] img[data-예시]');
    if (img && previewImg) previewImg.src = img.src;
  });
  on('[data-part] .btn', 'click', function (e, t) {
    var card = t.closest('[data-part]');
    if (!card) return;
    cs04담은것[card.dataset.part] = { nm: card.dataset.nm, add: Number(card.dataset.add) };
    cs04합계갱신();
  });

  /* ---------- ★ HO-01 히어로 평수 칩 — 고르면 예상 비용 띠가 바뀐다 ---------- */
  on('.pyeong-row .chip', 'click', function (e, t) {
    var row = t.closest('.pyeong-row');
    row.querySelectorAll('.chip').forEach(function (c) { c.classList.remove('on'); });
    t.classList.add('on');
    var val = row.querySelector('.pyeong-val');
    if (val && t.dataset.min) {
      val.innerHTML = t.textContent + ' 아파트 전체 시공 평균 <b>' + 만원(t.dataset.min) + ' ~ ' + 만원(t.dataset.max) + '</b>';
    }
  });

  /* ---------- ★ ES-01 견적 마법사 — 화면 하나에 6단계가 다 들어 있다.
     앞뒤로 오가도 답이 남고(단계는 감추기만 한다), 막대·「N단계 중 M번째」·오른쪽
     「지금까지 고른 조건」이 함께 따라 움직인다. ---------- */
  function 마법사그리기(wz) {
    var now = Number(wz.dataset.stepNow);
    var total = Number(wz.dataset.stepTotal);
    wz.querySelectorAll('[data-step]').forEach(function (p) {
      p.hidden = Number(p.dataset.step) !== now;
    });
    wz.querySelectorAll('[data-step-dot]').forEach(function (d) {
      var n = Number(d.dataset.stepDot);
      d.classList.toggle('on', n === now);
      d.classList.toggle('done', n < now);
    });
    var fill = wz.querySelector('.progress .fill');
    if (fill) fill.style.width = Math.round(now / total * 100) + '%';
    var label = wz.querySelector('[data-step-label]');
    if (label) label.textContent = total + '단계 중 ' + now + '번째';
    var prev = wz.querySelector('[data-step-prev]');
    if (prev) { prev.disabled = now === 1; prev.classList.toggle('is-off', now === 1); }
    var next = wz.querySelector('[data-step-next]');
    var done = wz.querySelector('[data-step-done]');
    if (next) next.hidden = now === total;
    if (done) done.hidden = now !== total;
  }
  on('[data-step-next]', 'click', function (e, t) {
    var wz = t.closest('[data-wizard]');
    var now = Number(wz.dataset.stepNow);
    if (now >= Number(wz.dataset.stepTotal)) return;
    wz.dataset.stepNow = now + 1;
    마법사그리기(wz);
  });
  on('[data-step-prev]', 'click', function (e, t) {
    var wz = t.closest('[data-wizard]');
    var now = Number(wz.dataset.stepNow);
    if (now <= 1) return;
    wz.dataset.stepNow = now - 1;
    마법사그리기(wz);
  });
  /* 막대의 단계 이름을 눌러서도 건너뛴다 — 이미 지나온 단계로 돌아가기 쉽게 */
  on('[data-step-dot]', 'click', function (e, t) {
    var wz = t.closest('[data-wizard]');
    wz.dataset.stepNow = t.dataset.stepDot;
    마법사그리기(wz);
  });
  /* 고른 답을 오른쪽 요약에 그대로 옮긴다 */
  document.addEventListener('change', function (e) {
    var f = e.target.closest('[data-field]');
    if (!f) return;
    var dd = document.querySelector('[data-answer="' + f.dataset.field + '"]');
    if (dd) dd.textContent = f.value;
  });
  /* 평수를 고치면 ㎡ 환산과 요약이 같이 바뀐다 (1평 = 3.3058㎡) */
  document.addEventListener('input', function (e) {
    var p = e.target.closest('[data-pyeong]');
    if (!p) return;
    var v = Number(p.value) || 0;
    var m2 = document.querySelector('[data-pyeong-m2]');
    if (m2) m2.textContent = (v * 3.3058).toFixed(1) + '㎡';
    var dd = document.querySelector('[data-answer="평수"]');
    if (dd) dd.textContent = v + '평';
  });
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-wizard]').forEach(마법사그리기);
  });

  /* ---------- ★ ES-01 견적 3단계 — 고른 공간에 따라 미리보기 금액이 바뀐다.
     아직 4·5단계(마감 등급·착공 시기)를 안 물은 시점이라, 확정 견적(ESTIMATE_BASE)보다
     낮은 범위 안에서만 움직인다 — 공간을 다 골라도 확정액을 넘어서면 안 된다. ---------- */
  on('[data-space-pick] input[type=checkbox]', 'change', function () {
    var pick = document.querySelector('[data-space-pick]');
    var checked = pick.querySelectorAll('input[type=checkbox]:checked');
    var names = Array.prototype.map.call(checked, function (c) { return c.dataset.space; });
    var listEl = document.querySelector('[data-space-list]');
    if (listEl) listEl.textContent = names.length ? names.join(', ') : '아직 고르지 않음';
    var priceEl = document.querySelector('[data-space-price]');
    if (priceEl) {
      var n = names.length;
      var min = 19500000 + n * 1500000;
      var max = 25600000 + n * 1800000;
      priceEl.textContent = 만원(min) + ' ~ ' + 만원(max);
    }
  });

  /* ---------- ★ ES-02 견적 결과 — 마감 등급 탭 · 「포함」 토글이 금액에 반영된다.
     data-base 는 「기본」(mult 1.0) 기준값이다 — 등급 탭을 누르면 base×mult 로
     다시 계산해서 각 칸·범위·공사 기간을 바꾸고, 합계는 켜진(포함) 줄만 더한다. ---------- */
  function es02합계() {
    var totalEl = document.querySelector('[data-grade-total]');
    if (!totalEl) return;
    var sum = 0;
    document.querySelectorAll('.toggle[data-base]').forEach(function (b) {
      if (b.classList.contains('on')) sum += Number(b.dataset.amt);
    });
    totalEl.textContent = 돈(sum);
  }
  on('[data-grade-pick] .tab', 'click', function (e, t) {
    var box = t.closest('[data-grade-pick]');
    box.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('on'); });
    t.classList.add('on');
    var mult = Number(t.dataset.mult);
    document.querySelectorAll('[data-base]').forEach(function (el) {
      var amt = Math.round(Number(el.dataset.base) * mult);
      el.dataset.amt = amt;
      if (!el.classList.contains('toggle')) el.textContent = 돈(amt);
    });
    var priceEl = document.querySelector('[data-grade-price]');
    if (priceEl) {
      priceEl.textContent = 돈(Number(priceEl.dataset.minBase) * mult) + ' ~ ' + 돈(Number(priceEl.dataset.maxBase) * mult);
    }
    var daysEl = document.querySelector('[data-grade-days]');
    if (daysEl) daysEl.textContent = t.dataset.days + '일 (주말 제외)';
    es02합계();
  });
  on('.toggle[data-base]', 'click', es02합계);

  /* ---------- ★ 준공 검수 — 괜찮음·문제있음 ---------- */
  on('[data-chk]', 'click', function (e, t) {
    var row = t.closest('.chk-row');
    if (!row) return;
    var buttons = row.querySelectorAll('[data-chk]');
    buttons.forEach(function (b) { b.classList.remove('on'); });
    t.classList.add('on');
    var sub = row.querySelector('.chk-sub');
    if (sub) sub.hidden = t.dataset.chk !== 'bad';
    row.classList.toggle('bad', t.dataset.chk === 'bad');
    var done = document.querySelectorAll('.chk-row [data-chk].on').length;
    var total = document.querySelectorAll('.chk-row').length;
    document.querySelectorAll('[data-chk-done]').forEach(function (x) { x.textContent = done; });
    document.querySelectorAll('[data-chk-total]').forEach(function (x) { x.textContent = total; });
    var submit = document.querySelector('[data-chk-submit]');
    if (submit) {
      var remain = total - done;
      submit.disabled = remain > 0;
      submit.classList.toggle('is-off', remain > 0);
      submit.textContent = remain > 0 ? '준공 승인하고 잔금 결제 (' + remain + '개 남음)' : '준공 승인하고 잔금 결제';
    }
  });

  /* ---------- 서명란 — 누르면 서명한 것으로 표시(프로토타입) ---------- */
  on('.sig-pad', 'click', function (e, t) {
    if (e.target.closest('.sig-clear')) return;
    t.classList.add('signed');
    t.textContent = '';
    var span = document.createElement('span');
    span.textContent = '(서명완료) 2026.08.17';
    t.appendChild(span);
    var clear = document.createElement('button');
    clear.className = 'btn btn-ghost btn-sm sig-clear';
    clear.type = 'button';
    clear.textContent = '지우기';
    t.appendChild(clear);
  });
  on('.sig-clear', 'click', function (e, t) {
    var pad = t.closest('.sig-pad');
    pad.classList.remove('signed');
    pad.textContent = '여기를 눌러 서명해 주세요';
  });

  /* 파일 올리기(프로토타입) — 누르면 썸네일이 하나 쌓인다 */
  on('.upload-drop', 'click', function (e, t) {
    var wrap = t.parentElement.querySelector('.upload-thumbs');
    if (!wrap) return;
    var item = document.createElement('div');
    item.className = 'u-item ph t' + ((wrap.children.length % 5) + 1);
    item.innerHTML = '<button type="button" aria-label="지우기">✕</button>';
    wrap.appendChild(item);
    toast('사진을 올렸어요');
  });
  on('.upload-thumbs button', 'click', function (e, t) {
    t.closest('.u-item').remove();
  });

  /* 카운트다운 */
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-count]').forEach(function (el) {
      var left = parseInt(el.dataset.count, 10) || 0;
      var p = function (n) { return (n < 10 ? '0' : '') + n; };
      var tick = function () {
        var h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
        el.textContent = h > 0 ? h + ':' + p(m) + ':' + p(s) : m + ':' + p(s);
        if (left <= 0) return;
        left--;
        setTimeout(tick, 1000);
      };
      tick();
    });
  });

  /* 행·카드 전체를 누르면 이동 — data-href */
  on('[data-href]', 'click', function (e, t) {
    if (e.target.closest('a, button, input, label, select, textarea')) return;
    location.href = t.dataset.href;
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    var t = e.target.closest && e.target.closest('[data-href]');
    if (t && e.target === t) location.href = t.dataset.href;
  });

  /* 토스트 */
  var tRef = null;
  function toast(msg, action, kind) {
    if (tRef) tRef.remove();
    var d = document.createElement('div');
    d.className = 'toast' + (kind === 'ok' ? ' toast-ok' : '');
    d.innerHTML = '<span></span>' + (action ? '<span class="act">' + action + '</span>' : '<span class="act" data-close=".toast">닫기</span>');
    d.firstChild.textContent = msg;
    document.body.appendChild(d);
    tRef = d;
    setTimeout(function () { if (d.parentNode) d.remove(); }, 3400);
  }
  window.toast = toast;
  on('[data-toast]', 'click', function (e, t) {
    toast(t.dataset.toast, t.dataset.toastAct || '', t.dataset.toastKind || '');
  });

  /* 화면 정보 패널 — 언제나 닫힌 채로 시작한다. 누를 때만 열린다. */
  on('.dev-btn', 'click', function (e, t) {
    var box = t.closest('.dev');
    box.classList.toggle('on');
  });

  /* 폼 전송은 프로토타입이므로 막고 안내만 */
  document.addEventListener('submit', function (e) {
    e.preventDefault();
    toast('프로토타입 화면이에요. 실제로 전송되지 않습니다');
  });

  /* 가로로 넘치는 줄 — 좌우 화살표로 넘긴다 */
  function carSync(box) {
    var wrap = box.closest('.car'); if (!wrap) return;
    var prev = wrap.querySelector('.car-nav.prev'), next = wrap.querySelector('.car-nav.next');
    var max = box.scrollWidth - box.clientWidth;
    if (prev) prev.disabled = box.scrollLeft <= 2;
    if (next) next.disabled = box.scrollLeft >= max - 2;
  }
  on('.car-nav', 'click', function (e, t) {
    var box = t.closest('.car').querySelector('.carousel');
    var card = box.firstElementChild;
    var step = card ? card.getBoundingClientRect().width + 20 : 288;
    box.scrollLeft += (t.classList.contains('prev') ? -1 : 1) * step * 2;
    setTimeout(function () { carSync(box); }, 350);
  });
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.car .carousel').forEach(function (b) {
      carSync(b);
      b.addEventListener('scroll', function () { carSync(b); });
    });
  });
})();
